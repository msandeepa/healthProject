from django.shortcuts import render
import json
# Create your views here.
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from telehealth.models import Patient
from telehealth.models import guest,Reason,Location 
from telehealth.serializers import GuestSerializer,ReasonSerializer,LocationSerializer

@api_view(['POST'])
def login(request):
	username_correct=False
	password_correct=False
	if request.method == 'POST':
		try:
			if Patient.objects.get(patient_mailid=request.data["username"]):
       	   		 username_correct=True
			elif Patient.objects.get(patient_password=request.data["password"]):
       	   		 patient_password=True
			if Patient.objects.get(patient_mailid=request.data["username"]) and Patient.objects.get(patient_password=request.data["password"]):
				res={
	       		  "Status" : "Success",
	       		  "Message" : "Login Sucessful"
	       		}
				return Response(res)
		except Patient.DoesNotExist:
			if  not username_correct:
				res={
		       	"Status" : "Failure",
		       	"Message" : "username does not exist"
		       	}
				return Response(res)
			if not password_correct:
				res={
	       		"Status" : "Failure",
	       		"Message" : "password is  not correct"
	       		}
				return Response(res)
	       	

@api_view(['GET', 'POST'])
def Guest(request):
    if request.method == 'GET':
        guests = guest.objects.all()
        serializer = GuestSerializer(guests, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = GuestSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(
                serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def reason_list(request):
    if request.method == 'GET':
        all_reasons = Reason.objects.all()
        serializer = ReasonSerializer(all_reasons, many=True)
        return Response(serializer.data)

@api_view(['GET'])
def location_list(request):
    if request.method == 'GET':
        all_locations = Location.objects.only("location_name")
        serializer = LocationSerializer(all_locations, many=True)
        return Response(serializer.data)