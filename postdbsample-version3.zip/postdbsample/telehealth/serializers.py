from rest_framework import serializers
from telehealth.models import guest,Reason,Location


class GuestSerializer(serializers.ModelSerializer):

    class Meta:
        model = guest
        fields = ('guest_id','guest_firstname','guest_lastname','guest_mail_id','guest_contact_number','guest_contact_person',
        	'guest_alternate_contact','guest_address_line_1','guest_address_line_2','guest_city','guest_zip_code','guest_DOB_dd',
        	'guest_DOB_mm','guest_DOB_yyyy')

class ReasonSerializer(serializers.ModelSerializer):
	class Meta:
		model = Reason
		fields = ('Reason_id','Reason')

class LocationSerializer(serializers.ModelSerializer):
	class Meta:
		model = Location
		fields = ('location_name',)

