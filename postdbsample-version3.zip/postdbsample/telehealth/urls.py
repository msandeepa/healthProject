from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^login/', views.login, name='login'),
    url(r'^guest/',views.Guest,name='guest'),
    url(r'^reasons/',views.reason_list,name='reasons'),
    url(r'^locations/',views.location_list,name='locations'),
    
]