from django.contrib import admin
from .models import Patient,Nurse,Slot,Appointment,Zone,Location,Doctor,guest,Reason
# Register your models here.
admin.site.register(Doctor)
admin.site.register(Patient)
admin.site.register(Nurse)
admin.site.register(Slot)
admin.site.register(Appointment)
admin.site.register(Zone)
admin.site.register(Location)
admin.site.register(guest)
admin.site.register(Reason)