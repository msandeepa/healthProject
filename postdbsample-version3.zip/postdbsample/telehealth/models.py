from django.db import models

# Create your models here.


class Doctor(models.Model):
    doctor_id = models.AutoField(primary_key=True)
    doctor_name = models.CharField(max_length=20)
    doctor_mailid = models.CharField(max_length=25)
    doctor_mobileno = models.CharField(max_length=12)
    doctor_location = models.CharField(max_length=40)
    doctor_password = models.CharField(max_length=20)
    
    def __str__(self):
        return '%s %s' %(self.doctor_name,self.doctor_location)

class Slot(models.Model):
    slot_id = models.AutoField(primary_key=True)
    slot_starttime = models.CharField(max_length=7)
    slot_endtime = models.CharField(max_length=7)

    def __str__(self):
        return '%s %s'%(self.slot_starttime,self.slot_endtime)

class Zone(models.Model):
    zone_id = models.AutoField(primary_key=True)
    zone_name = models.CharField(max_length=20)

    def __str__(self):
        return self.zone_name

class Location(models.Model):
	location_id = models.AutoField(primary_key=True)
	location_name = models.CharField(max_length=40)
	location_zoneid = models.ForeignKey(Zone, on_delete=models.CASCADE)
	
	def __str__(self):
		return self.location_name

class Patient(models.Model):
    patient_id = models.AutoField(primary_key=True)
    patient_name = models.CharField(max_length=20)
    patient_mailid = models.CharField(max_length=25)
    patient_mobileno = models.CharField(max_length=12)
    patient_location = models.CharField(max_length=40)
    patient_password = models.CharField(max_length=20)

    def __str__(self):
        return self.patient_name

class Nurse(models.Model):
    nurse_id = models.AutoField(primary_key=True)
    nurse_name = models.CharField(max_length=20)
    nurse_mailid = models.CharField(max_length=25)
    nurse_mobileno = models.CharField(max_length=12)
    nurse_location = models.CharField(max_length=40)
    nurse_password = models.CharField(max_length=20)

    def __str__(self):
        return self.nurse_name
class Appointment(models.Model):
    appointment_id = models.AutoField(primary_key=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    nurse = models.ForeignKey(Nurse, on_delete=models.CASCADE)
    slot = models.ForeignKey(Slot, on_delete=models.CASCADE)
    appointment_date = models.DateField('book on date')

    def __str__(self):
    	return str(self.appointment_date)
class guest(models.Model):
    guest_id = models.AutoField(primary_key=True)
    guest_firstname=models.CharField(max_length=20)
    guest_lastname=models.CharField(max_length=20)
    guest_mail_id=models.CharField(max_length=20)
    guest_contact_number=models.CharField(max_length=14)
    guest_contact_person=models.CharField(max_length=20)
    guest_alternate_contact=models.CharField(max_length=20)
    guest_address_line_1=models.CharField(max_length=20)
    guest_address_line_2=models.CharField(max_length=20)
    guest_city=models.CharField(max_length=20)
    guest_zip_code=models.BigIntegerField()
    guest_DOB_dd=models.CharField(max_length=2)
    guest_DOB_mm=models.CharField(max_length=2)
    guest_DOB_yyyy=models.CharField(max_length=4)

    def __str__(self):
        return str(self.guest_firstname)

class Reason(models.Model):
    Reason_id=models.AutoField(primary_key=True)
    Reason=models.CharField(max_length=100)
    def __str__(self):
        return str(self.Reason_id)