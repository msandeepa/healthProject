# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Appointment',
            fields=[
                ('appointment_id', models.AutoField(serialize=False, primary_key=True)),
                ('appointment_date', models.DateField(verbose_name='book on date')),
            ],
        ),
        migrations.CreateModel(
            name='Doctor',
            fields=[
                ('doctor_id', models.AutoField(serialize=False, primary_key=True)),
                ('doctor_name', models.CharField(max_length=20)),
                ('doctor_mailid', models.CharField(max_length=25)),
                ('doctor_mobileno', models.CharField(max_length=12)),
                ('doctor_location', models.CharField(max_length=40)),
                ('doctor_password', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='guest',
            fields=[
                ('guest_id', models.AutoField(serialize=False, primary_key=True)),
                ('guest_firstname', models.CharField(max_length=20)),
                ('guest_lastname', models.CharField(max_length=20)),
                ('guest_mail_id', models.CharField(max_length=20)),
                ('guest_contact_number', models.CharField(max_length=14)),
                ('guest_contact_person', models.CharField(max_length=20)),
                ('guest_alternate_contact', models.CharField(max_length=20)),
                ('guest_address_line_1', models.CharField(max_length=20)),
                ('guest_address_line_2', models.CharField(max_length=20)),
                ('guest_city', models.CharField(max_length=20)),
                ('guest_zip_code', models.BigIntegerField()),
                ('guest_DOB_dd', models.CharField(max_length=2)),
                ('guest_DOB_mm', models.CharField(max_length=2)),
                ('guest_DOB_yyyy', models.CharField(max_length=4)),
            ],
        ),
        migrations.CreateModel(
            name='Location',
            fields=[
                ('location_id', models.AutoField(serialize=False, primary_key=True)),
                ('location_name', models.CharField(max_length=40)),
            ],
        ),
        migrations.CreateModel(
            name='Nurse',
            fields=[
                ('nurse_id', models.AutoField(serialize=False, primary_key=True)),
                ('nurse_name', models.CharField(max_length=20)),
                ('nurse_mailid', models.CharField(max_length=25)),
                ('nurse_mobileno', models.CharField(max_length=12)),
                ('nurse_location', models.CharField(max_length=40)),
                ('nurse_password', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='Patient',
            fields=[
                ('patient_id', models.AutoField(serialize=False, primary_key=True)),
                ('patient_name', models.CharField(max_length=20)),
                ('patient_mailid', models.CharField(max_length=25)),
                ('patient_mobileno', models.CharField(max_length=12)),
                ('patient_location', models.CharField(max_length=40)),
                ('patient_password', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='Reason',
            fields=[
                ('Reason_id', models.AutoField(serialize=False, primary_key=True)),
                ('Reason', models.CharField(max_length=100)),
            ],
        ),
        migrations.CreateModel(
            name='Slot',
            fields=[
                ('slot_id', models.AutoField(serialize=False, primary_key=True)),
                ('slot_starttime', models.CharField(max_length=7)),
                ('slot_endtime', models.CharField(max_length=7)),
            ],
        ),
        migrations.CreateModel(
            name='Zone',
            fields=[
                ('zone_id', models.AutoField(serialize=False, primary_key=True)),
                ('zone_name', models.CharField(max_length=20)),
            ],
        ),
        migrations.AddField(
            model_name='location',
            name='location_zoneid',
            field=models.ForeignKey(to='telehealth.Zone'),
        ),
        migrations.AddField(
            model_name='appointment',
            name='nurse',
            field=models.ForeignKey(to='telehealth.Nurse'),
        ),
        migrations.AddField(
            model_name='appointment',
            name='patient',
            field=models.ForeignKey(to='telehealth.Patient'),
        ),
        migrations.AddField(
            model_name='appointment',
            name='slot',
            field=models.ForeignKey(to='telehealth.Slot'),
        ),
    ]
